import {Component} from '@angular/core';

const template: string = require('./footer.html');

@Component({
	selector: 'footer',
	template
})

export class FooterComponent {}
