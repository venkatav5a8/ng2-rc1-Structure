import {Component} from '@angular/core';

@Component({
  selector: 'container',
  template: `<div> Container </div>`
})

export class ContainerComponent {}